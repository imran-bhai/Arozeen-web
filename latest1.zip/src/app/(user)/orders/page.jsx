
"use client"
import Orders from '@/components/OrdersTable'

import React from 'react'


const page = () => {
  return (
    <div className="">
   <Orders />
   </div>
  )
}

export default page
