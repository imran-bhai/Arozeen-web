export const API_BASE_URL =
  process.env.NODE_ENV === "development"
    ? "https://tecjaunt.store/ecommerce-backend/api/"
    : "https://tecjaunt.store/ecommerce-backend/api/";
