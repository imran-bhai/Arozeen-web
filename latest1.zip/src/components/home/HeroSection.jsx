import React from "react";
import Slider from "../Swiper";



const HeroSection = () => {
  
  return (
    <div className="w-full ">
      <Slider />
    </div>
  );
};

export default HeroSection;
